package com.shop.constant;

public enum ItemCategory {
    TOP,BOTTOM,DRESS,ACCESSORY
}
